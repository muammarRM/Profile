const menuToggle = document.querySelector('.menu-toggle input');
const nav = document.querySelector('nav ul');
const navImg = document.querySelector('.logo img');

menuToggle.addEventListener('click', function() {
    nav.classList.toggle('slide');
    navImg.classList.toggle('logotype');
});